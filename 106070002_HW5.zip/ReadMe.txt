Compilation:
clang++ -std=c++11 selectK.cc

Input file: 
input.txt

Output file: 
QS.txt, PS.txt

OS: 
Software:

    System Software Overview:

      System Version: macOS 10.15.4 (19E266)
      Kernel Version: Darwin 19.4.0
      Boot Volume: MacOS

Compiler:
Apple clang version 11.0.3 (clang-1103.0.32.59)
Target: x86_64-apple-darwin19.4.0
Thread model: posix